let campoX = 100, cidadeX = 500; // Posições dos mundos (campo e cidade)
let itensCampo = [];
let itensCidade = [];
let itensColetados = 0;
let jogoEstado = 'campo'; // Estado do jogo (campo ou cidade)
let timer = 0;

function setup() {
  createCanvas(800, 400);
  // Adicionando itens do campo
  for (let i = 0; i < 5; i++) {
    itensCampo.push(new Item(campoX + random(50, 150), random(100, 200), 'campo'));
  }
  // Adicionando itens da cidade
  for (let i = 0; i < 5; i++) {
    itensCidade.push(new Item(cidadeX + random(50, 150), random(100, 200), 'cidade'));
  }
}

function draw() {
  background(220);

  // Desenhar mundo (campo ou cidade)
  if (jogoEstado === 'campo') {
    drawCampo();
  } else if (jogoEstado === 'cidade') {
    drawCidade();
  }

  // Desenhar itens coletáveis
  drawItens();

  // Mostrar contagem de itens coletados
  fill(0);
  textSize(18);
  text("Itens Coletados: " + itensColetados, 10, 30);
  text("Mundo: " + jogoEstado, 10, 60);
  
  // Verificar se o tempo de alternância acabou
  if (millis() - timer > 5000) { // Altera o mundo a cada 5 segundos
    jogoEstado = jogoEstado === 'campo' ? 'cidade' : 'campo';
    timer = millis();
  }
}

function drawCampo() {
  fill(34, 139, 34); // Cor do campo
  rect(0, height / 2, width, height / 2); // Desenha o campo
}

function drawCidade() {
  fill(169, 169, 169); // Cor da cidade
  rect(0, height / 2, width, height / 2); // Desenha a cidade
}

function drawItens() {
  // Desenhar itens do campo
  for (let i = 0; i < itensCampo.length; i++) {
    let item = itensCampo[i];
    if (item.coletado === false) {
      item.display();
    }
  }
  // Desenhar itens da cidade
  for (let i = 0; i < itensCidade.length; i++) {
    let item = itensCidade[i];
    if (item.coletado === false) {
      item.display();
    }
  }
}

// Classe para os itens coletáveis
class Item {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.coletado = false;
    this.diametro = 40;
  }

  display() {
    fill(this.tipo === 'campo' ? 'green' : 'blue');
    ellipse(this.x, this.y, this.diametro, this.diametro);
  }

  coletar() {
    this.coletado = true;
    itensColetados++;
  }
}

// Detecta colisão entre o jogador e os itens
function mousePressed() {
  if (jogoEstado === 'campo') {
    for (let i = 0; i < itensCampo.length; i++) {
      let item = itensCampo[i];
      if (dist(mouseX, mouseY, item.x, item.y) < item.diametro / 2 && !item.coletado) {
        item.coletar();
      }
    }
  } else if (jogoEstado === 'cidade') {
    for (let i = 0; i < itensCidade.length; i++) {
      let item = itensCidade[i];
      if (dist(mouseX, mouseY, item.x, item.y) < item.diametro / 2 && !item.coletado) {
        item.coletar();
      }
    }
  }
}
